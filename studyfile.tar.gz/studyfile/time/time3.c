﻿#include "time.h"
int main(void)
{
	time_t tNOW=-1;
	struct tm tmNow;
	char buf[100];
	struct timeval tv;
	struct timezone tz;
	int ret=-1;
	tNOW= time(NULL);//返回值的方式
//time(&tNOW);//指针做输出型参数的方式
	if(tNOW<0)
	{
		perror("time");
		return -1;
	}
//gettimeofday和settimeofday 函数测试
	memset(&tv,0,sizeof(tv));//将tv清零
	memset(&tz,0,sizeof(tz));//将tz清零
	ret=gettimeofday(&tv,&tz);
	if(ret<0)
	{
		perror("gettimeofday");
		return -1;
	}
	printf("gettimeofday函数测试\n");
	printf("seconde:%ld\n",tv.tv_sec);
	printf("seconde:%ld\n",tv.tv_usec);
	printf("timezone:%d\n",tz.tz_minuteswest);
	printf("timezone:%d\n",tz.tz_dsttime);
	return 0;
}