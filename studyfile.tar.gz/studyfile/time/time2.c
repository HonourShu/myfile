﻿#include "time.h"
int main(void)
{
	time_t tNOW=-1;
	struct tm tmNow;
	tNOW= time(NULL);//返回值的方式
//time(&tNOW);//指针做输出型参数的方式
	if(tNOW<0)
	{
		perror("time");
		return -1;
	}
	printf("1.time函数测试\n");
	printf("time:%ld\n\n",tNOW);
//2.ctime函数测试：ctime可以从time_t出发得到一个字符串格式的当前时间.
	printf("2.ctime函数测试\n");
	printf("ctime:%s\n",ctime(&tNOW));
	/*3.gtime函数测试:获取的时间中：年份是以1970为基准的差值，月份是0表示1月，小时数是以UTC时间的0时区为标准的小时数（北京是东8区，因此北京时间比这个时间大8）*/
	memset(&tmNow,0,sizeof(tmNow));//将tmNow清零
	gmtime_r(&tNOW,&tmNow);
	printf("3.gtime函数测试\n");
	printf("%d年%d月%d日%d时\n\n",tmNow.tm_year+1900,tmNow.tm_mon+1,tmNow.tm_mday,tmNow.tm_hour);
	/*4..localtime函数测试:localtime和gmtime的唯一区别就是localtime以当前计算机中设置的时区为小时的时间基准 */
	memset(&tmNow,0,sizeof(tmNow));//将tmNow清零
	localtime_r(&tNOW,&tmNow);
	printf("4.localtime函数测试\n");
	printf("%d年%d月%d日%d时\n\n",tmNow.tm_year+1900,tmNow.tm_mon+1,tmNow.tm_mday,tmNow.tm_hour);
//5.mktime asctime函数测试: mktime功能和time函数一样，asctime函数和ctime函数功能一样 参考上面的时间格式之间的转换图
	memset(&tmNow,0,sizeof(tmNow));//将tmNow清零
	localtime_r(&tNOW,&tmNow);
	printf("5.mktime函数 asctime函数测试\n");
	printf("mktime:%ld\n",mktime(&tmNow));
	printf("asctime:%s\n",asctime(&tmNow));
	return 0;
}