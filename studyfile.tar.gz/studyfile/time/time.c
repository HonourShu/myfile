﻿#include "time.h"
int main(void)
{
	time_t tNOW=-1;
	tNOW= time(NULL);//返回值的方式
//time(&tNOW);//指针做输出型参数的方式
	if(tNOW<0)
	{
		perror("time");
		return -1;
	}
	printf("time:%ld\n\n",tNOW);
	return 0;
}