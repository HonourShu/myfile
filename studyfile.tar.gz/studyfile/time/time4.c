﻿#include "time.h"
int main(void)
{
	time_t tNOW=-1;
	struct tm tmNow;
	char buf[100];
	struct timeval tv;
	struct timezone tz;
	int ret=-1;
	tNOW= time(NULL);//返回值的方式
//time(&tNOW);//指针做输出型参数的方式
	if(tNOW<0)
	{
		perror("time");
		return -1;
	}
//strftime函数测试
	memset(&tmNow,0,sizeof(tmNow));//将tmNow清零
	localtime_r(&tNOW,&tmNow);
	printf("strftime函数测试\n");
	memset(buf,0,sizeof(buf));//将buf清零
	strftime(buf,sizeof(buf),"%Y-%m-%d %H:%M:%S",&tmNow);
	printf("标准时间自定义格式输出为：\n[%s]\n",buf);
	return 0;
}