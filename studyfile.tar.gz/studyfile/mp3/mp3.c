﻿/**********************************************************
   Fliename          :    new_mp3.c
   Author            :   	 group
   Data              :   	2017.6
   Description         :   实现音乐的播放，顺序播放，可以切换上一曲、下一曲、暂停、继续，可以调节音量
   Function list        :    remind()
   **********************************************************/
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <signal.h>
#include <sys/stat.h>
#include <sys/ipc.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <linux/input.h>
#include <linux/soundcard.h>
#define START 1
#define PAUSE 0
int iLeft = 60;
int iRight = 20;
int remind()
{
	printf("\033[31m************Mp3 Player************\033[0m\n");
	printf("\033[31m________remind information________\033[0m\n");
	printf("\033[31m              1.play              \033[0m\n");
	printf("\033[31m          2.pasue/continue        \033[0m\n");
	printf("\033[31m               3.stop             \033[0m\n");
	printf("\033[31m               4.next             \033[0m\n");
	printf("\033[31m               5.prev             \033[0m\n");
	printf("\033[31m             6.voice up           \033[0m\n");
	printf("\033[31m             7.voice down         \033[0m\n");
	printf("\033[31m               8.exit             \033[0m\n");
	printf("\033[31m__________________________________ \033[0m\n");
}
struct song
{
	pid_t id;
	char music_name[50];
	struct song *next;
	struct song *prior;
};
struct song *p1,*p2,*head;
struct song *shm_buf;
int shmid;
int NameLen;
pid_t ChildPid;
int ContinuePauseFlag = PAUSE;
struct tm *ptr;
time_t t;
void *shm_memory = (void *)0;
/************************************************************************
Function         :    song *create_mp3_list
Description       :    创建歌曲链表
Call             :    fopen(),strcpy()
Call    by       :    main()
***********************************************************************/
struct song *create_mp3_list(void)
{
	FILE *list_fd;
	size_t size;
	size_t len;
	struct song *p;
	char *line = NULL;
	system("ls /media/sf_myubuntu/mp3/song>/media/sf_myubuntu/mp3/song_list.txt");
	if((list_fd = fopen("/media/sf_myubuntu/mp3/song_list.txt","r")) == NULL)
	{
		perror("open song list failure!\n");
		exit(1);
	}
	p1 = (struct song *)malloc(sizeof(struct song));
	if(NULL == p1)
	{
		printf("malloc error!\n");
		exit(0);
	}
	size = getline(&line,&len,list_fd);
	/* 将line复制到p1的music_name中 */
	strncpy(p1->music_name,line,strlen(line));
	head = p1;
	while((size =getline(&line,&len,list_fd)) != -1)
	{
		p2 = p1;
		p1 = (struct song *)malloc(sizeof(struct song));
		strncpy(p1->music_name,line,strlen(line));
		p2->next = p1;
		p1->prior = p2;
	}
	p1->next = head;
	head->prior = p1;
	p1 = NULL;
	p2 = NULL;
	return head;
}
/********************************************************************
Function         :    mp3_continue_pause
Description       :    实现歌曲的暂停和继续播放
Call             :    memcpy()
Call    by       :    main()
**********************************************************************/
void mp3_continue_pause(struct song *CurrentMusic)
{
	pid_t GrandPid;
	memcpy(&GrandPid,&CurrentMusic->id,sizeof(pid_t));
	if(ContinuePauseFlag == 0)
	{
		kill(ChildPid,SIGSTOP);
		kill(GrandPid,SIGSTOP);
		ContinuePauseFlag = 1;
		printf("\033[34mThe song is pause!\033[0m\n");
	}
	else if(ContinuePauseFlag == 1)
	{
		kill(ChildPid,SIGCONT);
		kill(GrandPid,SIGCONT);
		ContinuePauseFlag = 0;
		printf("\033[34mThe song is continue!\033[0m\n");
	}
}
/*****************************************************************
Function         :    mp3_play
Description       :    歌曲的播放方法
Call             :    strcat()
Call	by			 :    main()				:
*****************************************************************/
void mp3_play(struct song *CurrentMusic)
{
	char *dir;
	char dirname[40] ="/media/sf_myubuntu/mp3/song/";
	strcat(dirname,CurrentMusic->music_name);
	dir=dirname;
	NameLen = strlen(dir);
	dirname[NameLen - 1] = '\0';
	execlp("madplay","madplay","-q",dirname,NULL);
	perror("execlp");
}
/****************************************************************
 Function         :    mp3_start
Description        :    实现歌曲的播放
Call              :    mp3_play()
Call    by        :    main()
 ****************************************************************/
void mp3_start(struct song *CurrentMusic)
{
	pid_t GrandsonPid;
	struct song *nextmusic;
	memcpy(shm_buf,CurrentMusic,sizeof(struct song)); /*把current music拷到shmbuf*/
	ChildPid = fork();
	if(ChildPid < 0)
	{
		perror("fork failure!\n");
		exit(1);
	}
	if(ChildPid == 0)
	{
		while(1)
		{
			GrandsonPid = fork();
			if(GrandsonPid < 0)
			{
				perror("create Grandson process fail!\n");
				exit(1);
			}
			else
			{
				if(GrandsonPid == 0)
				{
					t = time(NULL);
					printf("\033[34mPrior song is: %s\033[0m\n",(shm_buf->prior)->music_name);
					printf("\033[34mNow is playing: %s\033[0m\n",shm_buf->music_name);
					printf("\033[34mNext song is: %s\033[0m\n",(shm_buf->next)->music_name);
					mp3_play(shm_buf);
				}
				else
				{
					shm_memory = shmat(shmid,(void *)0,0);
					if(shm_memory == (void *)-1)
					{
						perror("shmat fail!\n");
						exit(1);
					}
					shm_buf = (struct song *)shm_memory;
					memcpy(&shm_buf->id,&GrandsonPid,sizeof(pid_t));
					wait(&GrandsonPid);
				}
			}
		}
	}
}
/*****************************************************************
Function        :    mp3_stop
Description      :    实现歌曲的停止
Call            :    memcpy()
Call    by      :    main()
*****************************************************************/
void mp3_stop(struct song *CurrentMusic)
{
	pid_t GrandPid;
	memcpy(&GrandPid,&CurrentMusic->id,sizeof(pid_t));
	kill(ChildPid,SIGKILL);
	kill(GrandPid,SIGKILL);
}
/********************************************************************
Function        :    mp3_next
Description      :   实现歌曲切换到下一曲
Call            :   memcpy()
Call    by      :   main()
**********************************************************************/
void mp3_next(struct song *CurrentMusic)
{
	struct song *NextMusic;
	pid_t GrandPid;
	memcpy(&GrandPid,&CurrentMusic->id,sizeof(pid_t));
	kill(ChildPid,SIGKILL);
	kill(GrandPid,SIGKILL);
	NextMusic = CurrentMusic;
	NextMusic = NextMusic->next;
	wait(NULL);
	printf("\033[34mthe next song is %s\033[0m\n",NextMusic->music_name);
	mp3_start(NextMusic);
}
/*******************************************************************
    Function          :    mp3_prior
    Description        :   实现歌曲切换到上一曲
    Call              :   memcpy()
    Call    by        :   main()
    ********************************************************************/
void mp3_prior(struct song *CurrentMusic)
{
	pid_t GrandPid;
	struct song *PriorMusic;
	memcpy(&GrandPid,&CurrentMusic->id,sizeof(pid_t));
	kill(ChildPid,SIGKILL);
	kill(GrandPid,SIGKILL);
	PriorMusic = CurrentMusic;
	PriorMusic = PriorMusic->prior;
	wait(NULL);
	mp3_start(PriorMusic);
}
int main(void)
{
	shmid = shmget(IPC_PRIVATE,sizeof(struct song),0666 | IPC_CREAT);
	int MIX_FD= open("/dev/mixer", O_WRONLY);
	if(shmid < 0)
	{
		printf("create messge queue fail!\n");
		exit(1);
	}
	shm_memory = shmat(shmid,(void *)0,0);
	if(shm_memory == (void *)-1)
	{
		perror("shmat fail!\n");
		exit(1);
	}
	shm_buf = (struct song *)shm_memory;
	head = create_mp3_list();
	while(1)
	{
		char current_buttons[6];
		int a;
		remind();
		printf("\033[34mplease enter your choose:\033[0m\n");
		scanf("%d",&a);
		int iLevel;
		switch(a)
		{
		case 1:
			mp3_start(head);
			break;
		case 2:
			mp3_continue_pause(shm_buf);
			break;
		case 3:
			mp3_stop(shm_buf);
			printf("\033[34mnow song stops\033[0m\n");
			break;
		case 4:
			mp3_next(shm_buf);
			break;
		case 5:
			mp3_prior(shm_buf);
			break;
		case 6:
			iLeft += 5;
			iLevel = (iRight << 8) + iLeft;
			ioctl(MIX_FD, MIXER_WRITE(SOUND_MIXER_VOLUME), &iLevel);
			printf("\033[34mVolume has up\033[0m\n");
			break;
		case 7:
			iLeft -= 5;
			iLevel = (iRight << 8) + iLeft;
			ioctl(MIX_FD, MIXER_WRITE(SOUND_MIXER_VOLUME), &iLevel);
			printf("\033[34mVolume has down\033[0m\n");
			break;
		case 8:
			kill(0,SIGKILL);
			break;
		}
	}
	return 0;
}