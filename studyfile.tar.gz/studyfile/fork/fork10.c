﻿#include "fork.h"
void delete();
#define FILE "/var/aliya_tset_single"
int main(void)
{
	int fd=-1; //fd file descriptor,文件描述符
//第一步：判断文件是否存在，若是，则报错，否建立
	fd=open(FILE,O_CREAT|O_RDWR|O_TRUNC|O_EXCL,0664 );
	if(fd<0)
	{
		if(errno == EEXIST)
		{
			printf("进程已经存在，请勿重复执行！\n");
			return -1;
		}
	}
//第二步：进程执行完毕后删除这个文件。
	atexit(delete);
	int i=0;
	for(i=0; i<10; i++)
	{
		sleep(1);
		printf("running....%d\n",i);
	}
}
void delete()
{
	remove(FILE);//删除文件 
}