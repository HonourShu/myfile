﻿#include "fork.h"
int main(int argc,char *argv[])
{
	pid_t ret = -1;
	pid_t pid = -1;
	int status = -1; //
	
	pid = fork(); //创建子进程，返回两个pid，一个是父进程pid=0，一个是子进程pid>0

	if(pid == 0)
	{
//子进程
		printf("child ready\n");
		printf("child pid = %d\n",getpid());
	
		/*(1)使用execl和execlp分别运行ls -l -a*/
//execl("/bin/ls", "ls", "-l", "-a", NULL);
		execl("exec", "aaa", "bbb", NULL);
//execlp("ls", "ls", "-l", "-a", NULL);
		/*(2)使用execv和execvp运行ls*/
		//char *const arg[] = {"ls", "-l", "-a", NULL};
//execv("/bin/ls", arg);
		//execvp("ls", arg);
		/*(3)使用execle运行自己写的程序*/
//char *const envp[] = {"name=scorpio","host=192.168.6.200", NULL};
//execle("./exec", "exec", NULL, envp);
		return 0;
	}
	else if(pid > 0)
	{
		sleep(1);
//父进程
		printf("parent ready\n");
		printf("父进程pid=%d\n",pid);
//ret = waitpid(pid,&status,0);
//ret = waitpid(pid,&status,0);
		ret = waitpid(pid,&status,WNOHANG);
		printf("回收子进程,子进程pid=%d\n",ret);
		printf("是否正常退出:%d\n",WIFEXITED(status) );
		printf("是否非正常退出:%d\n",WIFSIGNALED(status) );
		printf("正常终止的进程返回值:%d\n",WEXITSTATUS(status) );
	}
	else
	{
//错误
		perror("fork");
	}
	printf("Code Access~\n");
	return 0;
}