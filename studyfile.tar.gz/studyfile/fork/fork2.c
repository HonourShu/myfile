﻿#include "fork.h"
int main(void)
{
	pid_t p1=-1;
	p1=fork();
	if (p1 == 0)
	{
//子进程操作
		printf("子进程，pid=%d.\n",getpid());
		printf("子进程，pid=%d.\n",getpid());
	}
	if (p1 > 0)
	{
//父进程操作
		printf("父进程，pid=%d.\n",getpid());
	}
	if (p1 < 0)
	{
//这里一定是fork出错了　
	}
//在这里所做的操作，在父子进程都有这个操作
	printf("helloworld,pid=%d\n",getpid());
	return 0;
	return 0;
}