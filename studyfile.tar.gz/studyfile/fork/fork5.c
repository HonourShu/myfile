﻿#include "fork.h"
int main(int argc,char *argv[])
{
	pid_t ret = -1;
	pid_t pid = -1;
	int status = -1; //
	pid = fork(); //创建子进程，返回两个pid，一个是父进程pid=0，一个是子进程pid>0 
	if(pid == 0)
	{
//子进程
		printf("child ready\n");
		printf("child pid = %d\n",getpid());
		exit(1);
	}
	else if(pid > 0)
	{
//父进程
		printf("parent ready\n");
		ret = wait(&status); //wait是阻塞式的，不用sleep
//status：提供给操作系统一个用户态指针，然后由内核来填充这个值
		printf("回收子进程,子进程pid=%d\n",ret);
		printf("是否正常退出:%d\n",WIFEXITED(status) );
	}
	else
	{
//错误
		perror("fork");
	}
	printf("Code Access~\n");
	return 0;
}