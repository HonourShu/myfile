﻿#include "fork.h"
void func(void)
{
	printf("hello No.2\n");
}
int main(void)
{
	printf("hello No.1\n");
	atexit(func);//调用atexith函数
	printf("hello No.3\n");
	return 0;
}