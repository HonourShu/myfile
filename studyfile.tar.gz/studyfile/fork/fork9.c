﻿#include "fork.h"
int main(void)
{
	printf("my pid = %d.\n", getpid());
	openlog("b.out", LOG_PID | LOG_CONS, LOG_USER);
//打印多条日志信息
	syslog(LOG_INFO, "this is my log info.%d", 23);
	syslog(LOG_INFO, "this is another log info.");
	syslog(LOG_INFO, "this is 3th log info.");
	closelog();
	return 0;
}