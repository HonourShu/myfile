﻿#include "fork.h"
int main(int argc,char *argv[])
{
		char cmd[10][100]= {"echo 请欣赏音乐","echo 广寒宫","madplay a.mp3"};
		system(cmd[0]);
		system(cmd[1]);
		system(cmd[2]);
	return 0;
}