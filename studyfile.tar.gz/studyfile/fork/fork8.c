﻿#include "fork.h"
void create_daemon(void);
int main(void)
{
	create_daemon();
	while (1)
	{
		printf("I am running.\n");
		sleep(1);
	}
	return 0;
}
// 函数作用就是把调用该函数的进程变成一个守护进程
void create_daemon(void)
{
	pid_t pid = 0;
	pid = fork();
	/*1、后台运行:子进程等待父进程退出 */
	if (pid < 0)
	{
		perror("fork");
		exit(-1);
	}
	if (pid > 0)
	{
		exit(0); // 父进程直接退出
	}
// 执行到这里就是子进程
/*2、脱离控制终端、登录会话和进程组 */
//setsid将当前进程设置为一个新的会话期session，目的就是让当前进程
// 脱离控制台.
	pid = setsid();
	/*3、改变当前工作目录*/
// 将当前进程工作目录设置为根目录
	chdir("/");
	/*4、umask设置为0以取消任何文件权限屏蔽*/
// umask设置为0确保将来进程有最大的文件操作权限
	umask(0);
	/*5、关闭所有文件描述符*/
//先要获取当前系统中所允许打开的最大文件描述符数目
	int cnt = sysconf(_SC_OPEN_MAX);
	int i = 0;
	for (i=0; i<cnt; i++)
	{
		close(i);
	}
	/*6.将0、1、2定位到/dev/null*/
///dev/null 这个文件下类似于回收站 存放垃圾的地方
	open("/dev/null", O_RDWR);
	open("/dev/null", O_RDWR);
	open("/dev/null", O_RDWR);
}