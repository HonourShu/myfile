﻿#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define OK 1
#define ERROR 0
#define TRUE 1
#define FALSE 0
#define MAXSIZE 20
typedef int Status;
typedef int SElemType;
typedef struct StackNode
{
	SElemType data;
	struct StackNode *next;
} StackNode, *LinkStackPtr;

typedef struct LinkStack
{
	LinkStackPtr top;
	int count;
} LinkStack;

Status InitStack(LinkStack *S)
{
	S->top=NULL;
	S->count=0;
	return OK;
}
Status Push(LinkStack *S, SElemType e)
{
	LinkStackPtr p=(LinkStackPtr)malloc(sizeof(StackNode));
	p->data=e;
	p->next=S->top;
	S->top=p;
	S->count++;
	return OK;
}

Status Pop(LinkStack *S, SElemType *e)
{
	LinkStackPtr p;
	if(S->count == 0)
		return ERROR;
	*e=S->top->data;
	p=S->top;
	S->top=S->top->next;
	free(p);
	S->count--;
	return OK;
}

Status ShowStack(LinkStack *S)
{
	if(S->count == 0)
		return ERROR;
	LinkStackPtr p;
	p=S->top;
	printf("\n");
	while(p != NULL)
	{
		printf("%d ",p->data);
		p=p->next;
	}
	printf("\n\n");
	return OK;
}

int main(void)
{
	LinkStack stack;
	char c;
	SElemType n;
	InitStack(&stack);
	while(1)
	{
		printf("1.元素入栈\n");
		printf("2.元素出栈\n");
		printf("3.元素遍历\n");
		printf("0.退出\n");
		printf("请输入选项:");
		scanf("%c",&c);
		getchar();
		switch(c)
		{
		case '1':
		{
			printf("输入要入栈的元素:\n");
			scanf("%d",&n);
			getchar();
			Push(&stack,n);
			break;
		}
		case '2':
		{
			Pop(&stack,&n);
			printf("出栈的元素为:[%d]\n",n);
			break;
		}
		case '3':
		{
			ShowStack(&stack);
			break;
		}
		case '0':
		{
			exit(0);
		}
		default:
			break;
		}
	}
	return 0;
}
