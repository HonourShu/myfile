﻿#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define OK 1
#define ERROR 0
#define TRUE 1
#define FALSE 0
#define MAXSIZE 20
typedef int Status;
typedef int Elemtype;
typedef struct
{
	Elemtype data[MAXSIZE];
	int length;
} SqList;

Status GetElem(SqList *L, int i, Elemtype *e)
{
	if(L->length==0 || i<1 || i>L->length)
		return ERROR;
	*e=L->data[i-1];
	return OK;
}

Status ListInsert(SqList *L, int i, Elemtype e)
{
	int k;
	if(L->length==MAXSIZE)
		return ERROR;
	if(i<1 || i>L->length+1)
		return ERROR;
	if(i<=L->length)
	{
		for(k=L->length-1; k>=i-1; k--)
			L->data[k+1]=L->data[k];
	}
	L->data[i-1]=e;
	L->length++;
	return OK;
}

Status ListDelete(SqList *L, int i, Elemtype *e)
{
	int k;
	if(L->length==0)
		return ERROR;
	if(i<1 || i>L->length)
		return ERROR;
	*e=L->data[i-1];
	if(i<L->length)
	{
		for(k=i; k<L->length; k++)
			L->data[k-1]=L->data[k];
	}

	L->length--;
	return OK;
}



int main(void)
{
	SqList list;
	int num, n;
	Elemtype m;
	printf("输入元素个数:\n");
	scanf("%d",&list.length);
	printf("输入元素:\n");
	for(int i=0; i<list.length; i++)
		scanf("%d",&list.data[i]);
	while(1)
	{
		printf("1.查找元素\n");
		printf("2.插入元素\n");
		printf("3.删除元素\n");
		printf("4.遍历元素\n");
		printf("0.退出\n");
		scanf("%d",&num);
		switch(num)
		{
		case 1:
		{
			printf("输入要获得的元素位置:\n");
			scanf("%d",&n);
			GetElem(&list,n,&m);
			printf("该元素为:[%d]\n",m);
			break;
		}
		case 2:
		{
			printf("输入插入的元素和位置:\n");
			scanf("%d%d",&m,&n);
			ListInsert(&list,n,m);
			break;
		}
		case 3:
		{
			printf("输入删除元素的位置:\n");
			scanf("%d",&n);
			ListDelete(&list,n,&m);
			printf("元素[%d]已删除\n",m);
			break;
		}
		case 4:
		{
			for(int i=0; i<list.length; i++)
				printf("%d ",list.data[i]);
			printf("\n");
			break;
		}
		case 0:
			exit(0);
		default:
			break;
		}
	}
	return 0;
}