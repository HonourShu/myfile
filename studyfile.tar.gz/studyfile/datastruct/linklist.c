﻿#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define OK 1
#define ERROR 0
#define TRUE 1
#define FALSE 0
typedef int Status;
typedef int ElemType;
typedef struct Node
{
	ElemType data;
	struct Node *next;
} Node;
typedef struct Node *LinkList;

Status GetElem(LinkList *L, int i, ElemType *e)
{
	int j;
	LinkList p;
	p=*L;
	p=p->next;
	j=1;
	while(p && j<i)
	{
		p=p->next;
		++j;
	}
	if(!p || j>i)
		return ERROR;
	*e=p->data;
	return OK;
}

Status ListInsert(LinkList *L, int i, ElemType e)
{
	int j;
	LinkList p, s;
	p=*L;
	j=1;
	while(p && j<i)
	{
		p=p->next;
		++j;
	}
	if(!p || j>i)
		return ERROR;
	s=(LinkList)malloc(sizeof(Node));
	s->data=e;
	s->next=p->next;
	p->next=s;
	return OK;
}

Status ListDelete(LinkList *L, int i, ElemType *e)
{
	int j;
	LinkList p, q;
	p=*L;
	j=1;
	while(p->next && j<i)
	{
		p=p->next;
		++j;
	}
	if(!(p->next) || j>i)
		return ERROR;
	q=p->next;
	p->next=q->next;
	*e=q->data;
	free(q);
	return OK;
}
void CreateList(LinkList *L,int n)
{
	LinkList p, r;
	int i;
	srand(time(0));
	*L=(LinkList)malloc(sizeof(Node));
	r=*L;
	for(i=0; i<n; i++)
	{
		p=(LinkList)malloc(sizeof(Node));
		p->data=rand()%100+1;
		r->next=p;
		r=p;
	}
	r->next=NULL;
}

Status ShowList(LinkList *L)
{
	LinkList p;
	p=*L;
	p=p->next;
	while(p)
	{
		printf("%d ",p->data);
		p=p->next;
	}
	printf("\n");
	return OK;
}

Status ClearList(LinkList *L)
{
	LinkList p, q;
	p=*L;
	p=p->next;
	while(p)
	{
		q=p->next;
		free(p);
		p=q;
	}
	(*L)->next=NULL;
	return OK;
}

int main(void)
{
	LinkList list;
	int n;
	char c;
	ElemType m;
	printf("请输入元素个数:\n");
	scanf("%d",&n);
	getchar();
	CreateList(&list,n);
	while(1)
	{
		printf("1.查找元素\n");
		printf("2.插入元素\n");
		printf("3.删除元素\n");
		printf("4.遍历元素\n");
		printf("5.清空元素\n");
		printf("0.退出\n");
		scanf("%c",&c);
		getchar();
		switch(c)
		{
		case '1':
		{
			printf("输入要获得的元素位置:\n");
			scanf("%d",&n);
			getchar();
			GetElem(&list,n,&m);
			printf("该元素为:[%d]\n",m);
			break;
		}
		case '2':
		{
			printf("输入插入的元素和位置:\n");
			scanf("%d %d",&m,&n);
			getchar();
			ListInsert(&list,n,m);
			break;
		}
		case '3':
		{
			printf("输入删除元素的位置:\n");
			scanf("%d",&n);
			getchar();
			ListDelete(&list,n,&m);
			printf("元素[%d]已删除\n",m);
			break;
		}
		case '4':
		{	
			ShowList(&list);
			break;
		}
		case '5':
		{	
			ClearList(&list);
			break;
		}
		case '0':
			exit(0);
		default:
			break;
		}
	}
	return 0;
}