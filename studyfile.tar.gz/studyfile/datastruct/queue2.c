﻿#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define OK 1
#define ERROR 0
#define TRUE 1
#define FALSE 0
#define MAXSIZE 20
typedef int Status;
typedef int QElemType;
typedef struct QNode
{
	QElemType data;
	struct QNode *next;
}QNode, *QueuePtr;

typedef struct
{
	QueuePtr front, rear;
}LinkQueue;

Status InitQueue(LinkQueue *Q)
{
	if(!Q)
	{
		return ERROR;
	}
	QueuePtr p = (QueuePtr)malloc(sizeof(QNode));
	p->next = NULL;
	Q->front = Q->rear = p;
	return OK;
}
Status EnQueue(LinkQueue *Q, QElemType e)
{
	if(!Q)
		return ERROR;
	QueuePtr s=(QueuePtr)malloc(sizeof(QNode));
	if(!s)
		return ERROR;
	s->data=e;
	s->next=NULL;
	Q->rear->next=s;
	Q->rear=s;
	return OK;
}

Status DeQueue(LinkQueue *Q, QElemType *e)
{
	if(!Q)
		return ERROR;
	QueuePtr p;
	if(Q->front == Q->rear)
		return ERROR;
	p=Q->front->next;
	*e=p->data;
	Q->front->next=p->next;
	
	if(Q->rear == p)
		Q->rear=Q->front;
	free(p);
	return OK;
}

Status ShowQueue(LinkQueue *Q)
{
	if(!Q)
		return ERROR;
	QueuePtr p = Q->front->next;
	while(p)
	{
		printf("%d ",p->data);
		p=p->next;
	}
	printf("\n");
	return OK;
}
int main(void)
{
	LinkQueue queue;
	int n, m, count, num;
	
	srand(time(0));
	InitQueue(&queue);
	printf("请输入放入队列的元素个数:\n");
	scanf("%d",&n);
	printf("放入的元素为:\n");
	for(int i=0;i<n;i++)
	{
		num=rand()%100+1;
		printf("%d ",num);
		EnQueue(&queue,num);
	}
	printf("\n");
	printf("输出的元素为:\n");
	ShowQueue(&queue);
	return 0;
}