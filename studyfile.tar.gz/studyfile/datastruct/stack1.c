﻿#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define OK 1
#define ERROR 0
#define TRUE 1
#define FALSE 0
#define MAXSIZE 20
typedef int Status;
typedef int SElemType;
typedef struct
{
	SElemType data[MAXSIZE];
	int top;
}SqStack;
//初始化栈
Status InitStack(SqStack *S)
{
	S->top=-1;
	return OK;
}
//压栈
Status Push(SqStack *S, SElemType e)
{
	if(	S->top == MAXSIZE -1)
		return ERROR;
	S->top++;
	S->data[S->top]=e;
	return OK;
}
//弹栈
Status Pop(SqStack *S, SElemType *e)
{
	if(S->top == -1)
		return ERROR;
	*e=S->data[S->top];
	S->top--;
	return OK;
}
//遍历栈

Status ShowStack(SqStack *S)
{
	if(S->top == -1)
		return ERROR;
	for(int i=0;i<=S->top;i++)
	{
		printf("%d ",S->data[i]);
	}
	printf("\n");
	return OK;
}

int main(void)
{
	SqStack stack;
	char c;
	SElemType n;
	InitStack(&stack);
	while(1)
	{
		printf("1.元素入栈\n");
		printf("2.元素出栈\n");
		printf("3.元素清空\n");
		printf("4.元素遍历\n");
		printf("0.退出\n");
		scanf("%c",&c);
		getchar();
		switch(c)
		{
			case '1':
			{
				printf("输入要入栈的元素:\n");
				scanf("%d",&n);
				getchar();
				Push(&stack,n);
				break;
			}
			case '2':
			{
				Pop(&stack,&n);
				printf("出栈的元素为:[%d]\n",n);
				break;
			}
			case '3':
			{
				InitStack(&stack);
				printf("栈已清空\n");
				break;
			}
			case '4':
			{
				ShowStack(&stack);
				break;
			}
			case '0':
			{
				exit(0);
			}
			default:
				break;
		}
	}
	return 0;
}
