﻿#include "net.h"
// 服务器开放给我们的IP地址和端口号
#define SERADDR		"10.0.2.15"
#define SERPORT	    9003

char sendbuf[100]={0};
int main()
{
	int sockfd = -1, ret = -1;
	struct sockaddr_in seraddr = {0}; //绑定给sockfd的协议地址。
	struct sockaddr_in cliaddr = {0};//用来接收客户端的协议地址
	// 第1步：先socket打开文件描述符
	sockfd=socket(AF_INET,SOCK_STREAM,0);//选择性打开socket
	if(-1==sockfd)
	{
		perror("socket erroe!");
		return -1;
	}
	printf("sockfd=%d.\n",sockfd);
	//第2步：connect链接服务器
	seraddr.sin_family=AF_INET;//设置地址族为IPv4
	seraddr.sin_port=htons(SERPORT);	//设置地址的端口号信息
	seraddr.sin_addr.s_addr=inet_addr(SERADDR);//设置IP地址
	ret = connect(sockfd, (const struct sockaddr *)&seraddr, sizeof(seraddr));
	if (ret < 0)
	{
		perror("listen");
		return -1;
	}
	printf("已接入服务器, ret = %d.\n", ret);
	while(1)
	{
		memset(sendbuf,0,sizeof(sendbuf));
		printf("请输入消息:\n");
		scanf("%s",sendbuf);
		send(sockfd,sendbuf,strlen(sendbuf),0);
		if(strncmp(sendbuf,"end",3) ==0)
			break;
	}
	close(sockfd);
	return 0;
}