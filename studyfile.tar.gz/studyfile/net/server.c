﻿#include "net.h"
//定义的网络端口号及IP分配的地址
#define SERADDR		"10.0.2.15"
#define SERPORT	  9003
#define BACKLOG		100
char recvbuf[100]={0};
void *playmp3()
{
	system("madplay a.mp3");
	return 0;
}
int main()
{
	pthread_t tid;
	int sockfd = -1, ret = -1, clifd = -1;
	socklen_t len = 0;
	struct sockaddr_in seraddr = {0}; //绑定给sockfd的协议地址。
	struct sockaddr_in cliaddr = {0};//用来接收客户端的协议地址
	// 第1步：先socket打开文件描述符
	sockfd=socket(AF_INET,SOCK_STREAM,0);//选择性打开socket
	if(-1==sockfd)
	{
		perror("socket erroe!");
		return -1;
	}
	printf("sockfd=%d.\n",sockfd);
	// 第2步：bind绑定sockefd和当前电脑的ip地址&端口号
	seraddr.sin_family=AF_INET;//设置地址族为IPv4或者IPv6,这里设置为IPv4
	seraddr.sin_port=htons(SERPORT);
//设置地址的端口号信息htons()用来将整型变量从主机字节顺序转变成网络字节顺序
	seraddr.sin_addr.s_addr=inet_addr(SERADDR);//设置IP地址，并将点分IP转化为10进制格式
	bind(sockfd, (const struct sockaddr *)&seraddr, sizeof(seraddr));
	// 第三步：listen监听端口
	ret=listen(sockfd, BACKLOG);
	if(-1==ret)
	{
		perror("listen erroe!");
		return -1;
	}
	printf("阻塞式等待客户端来连接服务器\n");
	//第四步：accept阻塞等待客户端接入,在此期间会阻塞等待客户端来连接服务器
	clifd=accept(sockfd, (struct sockaddr *)&cliaddr, &len);
	printf("连接已经建立，client fd = %d.\n", ret);
	while(1)
	{
		recv(clifd,recvbuf,sizeof(recvbuf),0);
		printf("来自客户端的消息:\n");
		printf("[%s]\n",recvbuf);
		if(strncmp(recvbuf,"end",3) ==0)
			break;
		if(strncmp(recvbuf,"mp3",3) ==0)
		{
			pthread_create(&tid,NULL,playmp3,NULL);
			pthread_join(tid,NULL);
		}
			
		memset(recvbuf,0,sizeof(recvbuf));
	}
	close(clifd);
	close(sockfd);
	return 0;
}