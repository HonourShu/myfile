﻿#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(void)
{
	char buf[100] = {0};
	printf("请输入一个字符串，以回车结束\n");
	while(scanf("%s",buf))
	{
//去比较输入的是否为end，是则退出，不是则继续
		if(strncmp(buf,"end",3)==0)
		{
			printf("程序结束\n");
			break;
		}
		printf("本次输入了%d个字符\n",strlen(buf));
		memset(buf,0,sizeof(buf));
	}
	return 0;
}
