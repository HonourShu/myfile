﻿#include "thread.h"

char buf[100] = {0};
sem_t sem;
unsigned int flag=0;
void *func(void *arg)//子线程计数
{
//子线程首先应该有个循环
	/*循环中阻塞在等待主线程激活的时候，子线程被激活后就去获取buf中的字符长度，然后打印，完成后再次阻塞*/
	while(flag==0)
	{
//②等待信号量，信号量没来之前一直阻塞在这里
		sem_wait(&sem);
		printf("本次输入了%d个字符\n",strlen(buf));
		memset(buf,0,sizeof(buf));//清除buf
		//sem_wait(&sem);
	}
	pthread_exit(NULL);//线程终止
}
int main(void)
{
	pthread_t th = -1;
	int ret = -1;
//①信号量初始化
	sem_init (&sem, 0, 0);
	/* 创建线程 */
	ret = pthread_create(&th, NULL, func, NULL);
	if(ret !=0)
	{
		perror("pthread_create error.\n");
		return -1;
	}
	printf("请输入一个字符串，以回车结束\n");
	while(scanf("%s",buf))
	{
//去比较输入的是否为end，是则退出，不是则继续
		if(strncmp(buf,"end",3)==0)
		{
			printf("程序结束\n");
//return 0;
			flag=1;//标志量为1.则结束
//③释放信号量
			sem_post(&sem);
			break;
		}
		/*主线程在收到用户收入的字符串，并且确认不是end后，就去发信号激活子 进程来计数*/
//子线程被阻塞，主线程可以激活，这就是线程的同步问题。
//信号量就可以用来实现线程同步
		sem_post(&sem);//继续时也释放信号量
	}
//回收子线程
	printf("等待回收子线程\n");
	ret=pthread_join(th, NULL );
	if(ret!=0)
	{
		perror("pthread_join error.\n");
		return -1;
	}
	printf("子线程回收成功\n");
//④销毁信号量
	sem_destroy(&sem);//销毁信号量
	return 0;
}