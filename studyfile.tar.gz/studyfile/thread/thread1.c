﻿#include "thread.h"
void *thread_run( void * arg )
{
	printf("new thread dead\n");
	pthread_detach(pthread_self());
	return NULL;
}
int main( void )
{
	pthread_t tid;
	if ( pthread_create(&tid, NULL, thread_run, "thread1 run...") != 0 )
	{
		printf("create thread");
	}
	void *ret;
	sleep(1);
	if ( pthread_join(tid, NULL ) == 0 )
	{
		printf("pthread wait success,ret:%d\n",(int )ret);
	}
	else
	{
		printf("pthread wait failed\n");
	}
	return 0;
}