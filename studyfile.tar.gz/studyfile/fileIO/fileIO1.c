#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

int main(int argc,char *argv[])
{
	int fd=-1; //fd file descriptor,文件描述符
	char buf[100]= {0};
	char writebuf[20]="are you ok ?\n";
	int ret=-1;
//第一步：打开文件
	fd=open("a.txt",O_RDWR);
	if(-1 == fd)
	{
		printf("文件打开错误\n");
	}
	else
	{
		printf("文件打开成功，fd=%d.\n",fd);
	}
//第二步：读写文件
//写文件
	ret=write(fd,writebuf,strlen(writebuf));
	if(-1==ret)
	{
		printf(" 写入失败\n");
	}
	else
	{
		printf(" 实际写入了%d字节.\n",ret);
		printf(" 文件内容是: [%s] .\n",writebuf);
	}
//读文件
	ret=read(fd,buf,20);
	if(-1==ret)
	{
		printf(" 读取失败\n");
	}
	else
	{
		printf(" 实际读取了%d字节.\n",ret);
		printf(" 文件内容是: [%s] .\n",buf);
	}
//第三步：关闭文件
	close(fd);
	return 0;
}
