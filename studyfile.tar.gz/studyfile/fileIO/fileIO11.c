﻿#include "fileIO.h"
int main(void)
{
// 读取鼠标
	int fd = -1;
	char buf[200];
	int ret=-1;
	fd_set myset;
	struct timeval tim;
	fd = open("/dev/input/mouse0", O_RDONLY | O_NONBLOCK);
	if (fd < 0)
	{
		perror("open:");
		return -1;
	}
// 当前有2个fd，一个是fd：用于鼠标，一个是标准输入0 键盘
	/* 设置读集合，设置操作必须放在循环内 */
	FD_ZERO(&myset); //清空读集合
	FD_SET(fd, &myset); //将fd设置到读集合中
	FD_SET(0, &myset);//将标准输入0也设置到读集合中
	/* 设置超时时间，设置必须放在循环内 */
	tim.tv_sec= 3; //秒
	tim.tv_usec= 0; //微秒
	/* -如果集合中没有描述符响应
	* 1.如果第四个参数被设为NULL，select将一直阻塞知道集
	* 合中描述符有响应为止
	* 2.如果第四个参数设置了超时时间，时间到则函数超时返回
	* -如果集合中有一个或多个描述符响应，则集合被内核重新设
	* 置，用于存放有响应的描述符，设置的超时时间也被清空*/
	ret = select(fd+1, &myset, NULL, NULL, &tim);
	if (ret < 0)//说明函数调用失败，errno被设置
	{
		perror("select: ");
		return -1;
	}
	else if (ret == 0)//返回0说明没有一个描述符准备好。
	{
		printf("超时了\n");
	}
	else //返回有响应的文件描述符的数量
	{
// 等到了一路IO，然后去监测到底是哪个IO到了，处理之
		if (FD_ISSET(0, &myset))
		{
// 这里处理键盘
			memset(buf, 0, sizeof(buf));
			read(0, buf, 5);
			printf("键盘读出的内容是：[%s].\n", buf);
		}
		if (FD_ISSET(fd, &myset))
		{
// 这里处理鼠标
			memset(buf, 0, sizeof(buf));
			read(fd, buf, 50);
			printf("鼠标读出的内容是：[%s].\n", buf);
		}
	}
	return 0;
}