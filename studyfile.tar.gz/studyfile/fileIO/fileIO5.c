﻿#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#define Name "1.txt"
int main(void)
{
	int dout=-1;
	struct stat buf;
	memset(&buf,0,sizeof(buf));//memset后buf中全是0
	dout=stat(Name,&buf);//stat后buf就有内容了
	if(dout<0)//失败
	{
		perror("stat error");
		exit(-1);
	}
//成功获取了stat结构体，从中打印出各种文件属性信息
	printf("st_nlink=%ld.\n",buf.st_nlink);
	printf("st_size=%ld.\n",buf.st_size);
	printf("st_mode=%d.\n",buf.st_mode);
	return 0;
}