﻿#include "fileIO.h"
int main(void)
{
// 读取键盘
// 键盘就是标准输入，故为0号文件描述符，stdin
	char buf[100];
	memset(buf, 0, sizeof(buf));
	printf("before read.\n");
	read(0, buf, 5);
	printf("读出的内容是：[%s].\n", buf);
	return 0;
}