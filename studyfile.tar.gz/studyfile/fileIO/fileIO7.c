﻿#include <sys/types.h>
#include <dirent.h>
#include <stdio.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

int traverse_dir(const char *path)
{
	unsigned int cnt = 0;
	struct dirent **dent;
	unsigned int i = 0;
	i = scandir(path, &dent, NULL, NULL);
	while(*dent)
	{
		printf("name：[%s] \n", (*dent)->d_name);
		dent++;
		cnt++;
	}
	printf("总文件数为：%d\n", cnt);
	return 0;
}
int main(int argc, char **argv)
{
	if (argc != 2)
	{
		printf("usage: %s dirname\n", argv[0]);
		return -1;
	}
	traverse_dir(argv[1]);
}