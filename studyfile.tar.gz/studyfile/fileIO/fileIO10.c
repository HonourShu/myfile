﻿#include "fileIO.h"
int main(void)
{
	char buf[100] = {0};
	int fd = -1, ret = -1;
	/* 开两个进程，父进程读鼠标，子进程读键盘 */
	ret = fork();
	if(ret == 0)//为0，表示还没有接收到东西
	{
		while(1)
		{
			/* 读键盘 */
			memset(buf, 0, sizeof(buf));
			ret=read(0, buf, 5);
			if(ret > 0)
			{
				printf("键盘读出的内容是：[%s].\n", buf);
			}
		}
	}
	else if(ret > 0)
	{
		fd = open("/dev/input/mouse0", O_RDONLY |O_NONBLOCK);
		if(fd < 0)
		{
			perror("open error");
			return -1;
		}
		while(1)
		{
			/* 读鼠标 */
			memset(buf, 0, sizeof(buf));
			ret = read(fd, buf, 50);
			if(ret > 0)
			{
				printf("鼠标读出的内容是：[%s].\n", buf);
			}
		}
	}
	return 0;
}