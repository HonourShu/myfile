﻿#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#define FILENAME "1.txt"
int main(void)
{
	int fd1=-1,fd2=-1;
	fd1=open(FILENAME,O_CREAT|O_RDWR|O_TRUNC, 0644);
	if(fd1<0)
	{
		perror("open");
		return -1;
	}
	printf("fd1=%d.\n",fd1);
	close(1);//1就是标准输出stdout,关闭1
	/*当1被关闭后，当前最小且未用的文件描述符肯定是1，所以dup会将fd1复制到当前最小未用的1上，这样一来1和fd1都指向了文件1.txt */
//复制文件描述符
	fd2=dup(fd1);
	printf("fd2 = %d.\n", fd2);
	printf("hello world\n");
	return -1;
}